//Author: Kylie Hall
//Selection Sort Algorithm
import java.util.Arrays;
import java.util.Scanner;
import java.util.Random;

class Main {
  public static void main(String[] args) {
    
    Main Select =  new Main();

    final int SIZE_OF_ARRAY = 25;
    final int MIN_VALUE = 600;
    final int MAX_VALUE = 700;
    
		int[] myArray = new int[SIZE_OF_ARRAY]; //creation of array "myArray" 

Select.populateArrayWithRandomValues(myArray, MIN_VALUE, MAX_VALUE); //object to populate array
		
		System.out.println("Array Before: ");
		for(int element: myArray) {
			System.out.print(element);
		}

    int[] mySortedArray = new int[SIZE_OF_ARRAY];
    for(int i = 0; i < SIZE_OF_ARRAY; i++)
            mySortedArray[i] = myArray[i];
		sort(myArray);
		
		System.out.println("\n" + "Array After: ");
		for(int element: myArray) {
			System.out.print(element);
		}
  }

  public static void sort(int myArray[]){
    int n = myArray.length;
    //for loop to move through sub array
    for(int i=0; i<n-1; i++){
         int min_idx = i;
      for(int j=i+1; j<n; j++)
        if(myArray[j] < myArray[min_idx])
          min_idx = j;

        //swap elements
        int temp = myArray[min_idx];
        myArray[min_idx] = myArray[i];
        myArray[i] = temp;
    }
  }

  void populateArrayWithRandomValues(int[] myArray, int lowerBoundary, int upperBoundary){
     Random myRandomObject1 = new Random();

    for(int i=0; i<myArray.length; i++) {
			myArray[i] = myRandomObject1.nextInt(upperBoundary-lowerBoundary); // populate random numbers from 0-25
  }
}
}
