
/**
*Author: Kylie Hall


/**
*Author: Kylie Hall

*Created on Jan 27, 2023

*Code Summary
- INSERTION SORT
- Time complexity:
    Worst case: O(n^2)
    Best case: O(n) --> 1+1+1+1+...+1 (n times) this worst case is applicable to insertion sort but not bubble sort for example.
  Example:
  8 1 4 7 2
  1 8 4 7 2
  1 4 8 7 2
  1 4 7 8 2
  1 4 7 2 8
  1 4 2 7 8
  1 2 4 7 8 Done!
*/
import java.util.Arrays;
import java.util.Scanner;
//import java.util.Random;

class Main {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		//Random rn = new Random();

		System.out.println("Enter desired length of array...");
		int SIZE_OF_ARRAY = input.nextInt();
		final int MIN_VALUE = 600;
		final int MAX_VALUE = 700;

		int[] myArray = new int[SIZE_OF_ARRAY];

		System.out.println("Enter elements of the array separately: ");
		for (int i = 0; i < myArray.length; i++) {
			myArray[i] = input.nextInt();
		}

		//for random integers
		/*
		 * for(int i=0; i<myArray.length; i++) { myArray[i] = rn.nextInt(10); //random
		 * numbers from 0-25 }
		 */
		System.out.println(); //for output appearance
		System.out.println("Array Before: ");
		for (int element : myArray) {
			System.out.print(element + " ");
		}

		sort(myArray);
    
    System.out.println();//for output appearance
		System.out.println("\n" + "Array After: ");
		for (int element : myArray) {
			System.out.print(element + " ");
		}
	}

	public static void sort(int myArray[]) {
		int n = myArray.length;
		for (int i = 1; i < n; i++) { // iterate from myArray[1] to myArray[N]
			int keyelem = myArray[i]; // compare current element (keyelem) to the element before it (ie j as seen
										// below *!!)
			int j = i - 1; // !!

			while (j >= 0 && myArray[j] > keyelem) {
				myArray[j + 1] = myArray[j];
				j = j - 1;
			}
			myArray[j + 1] = keyelem;
		}
	}
}