/**
 * Author: Kylie Hall
 * Created on: February 7th, 2023
 */



import java.util.Arrays;
import java.util.Scanner;
import java.util.Random;





/*
 *  We define a new type using the keyword "record", which has
 *  been in existence since Java 14. Records are similar to
 *  classes, but with less ceremony (i.e., simpler syntax) and
 *  less features. They come equipped with inbuilt constructors,
 *  accessors, and toString() methods.
 */
record indexOf2DArray(int row, int column) {}





public class PeakFinder
{
    public static void main(String[] args)  {  // your program execution begins here
        // We're going to use the following object to invoke all the methods.
        PeakFinder myDummyObject  =  new PeakFinder();
        
        
        // Specify the allowable limits for all the parameters regarding the 2D array of integers.
        final int MIN_ROW_DIM = 6;
        final int MAX_ROW_DIM = 11;
        final int MIN_COL_DIM = 6;
        final int MAX_COL_DIM = 11;
        final int MIN_VALUE = 100;
        final int MAX_VALUE = 999;
        
        // Get the 2D array filled with random integers from the specified interval/
        int[][] myRandom2DArray  =  myDummyObject.createRandom2DArray(MIN_ROW_DIM, MAX_ROW_DIM, MIN_COL_DIM, MAX_COL_DIM, MIN_VALUE, MAX_VALUE);
        final int M = myRandom2DArray.length;
        final int N = myRandom2DArray[0].length;
        
        // Check that the 2D random array has been created alright.
        System.out.print("Please find below the contents of the 2D array named");
        System.out.println(" \"myRandom2DArray\", which has got " + M + " rows and " + N + " columns:\n\n");
        for(int i = 0; i < M; i++)  {
            for(int j = 0; j < N; j++)
                System.out.printf("%7d", myRandom2DArray[i][j]);
            System.out.println("\n");
        }
        
        
        // Now we're ready to find a peak!
        indexOf2DArray peakLocation  =  myDummyObject.peakFinder2D(myRandom2DArray);
        System.out.print("\nFor the above 2D array, a peak exists at");
        System.out.print(" row " + peakLocation.row() + " and column " + peakLocation.column());
        System.out.print(". The value of this peak is ");
        System.out.println(myRandom2DArray[peakLocation.row()][peakLocation.column()] + ".\n\n");
    }  // end of the main method





    public int[][] createRandom2DArray(int minRowDim, int maxRowDim, int minColDim, int maxColDim, int minValue, int maxValue)  {
        Random myRand1  =  new Random();
        
        //  Choose the number of rows uniformly at random from the specified range.
        int m = minRowDim + myRand1.nextInt(maxRowDim - minRowDim + 1);
        
        //  Choose the number of columns uniformly at random from the specified range.
        int n = minColDim + myRand1.nextInt(maxColDim - minColDim + 1);
        
        // Declare the 2D array and allocate memory. Remember that m is the number of rows and n is the number of columns.
        int[][] myRandom2DArray  =  new int[m][n];
        
        // Now populate the newly created 2D array with random integers from the specified range.
        for(int i = 0; i < m; i++)
            for(int j = 0; j < n; j++)
                myRandom2DArray[i][j]  =  minValue + myRand1.nextInt(maxValue - minValue + 1);
        
        // Return the 2D array, which is now filled with random integers from the specified range.
        return myRandom2DArray;
    }





    public indexOf2DArray peakFinder2D(int[][] some2DArray)  {
        /*
         * The following two variables, namely, "row" and column", have been
         * initialized with are arbitrary toy-values. Your algorithm is
         * supposed to find a correct pair of values for these two variables.
         */
        int row = 3, column = 4;
        
        
        // @Students, your code for implementing the peak-finding algorithm goes here.
        
        
        /*
         *  Finally, you create a data-carrier for the two integer variables,
         *  namely,"row" and "column", and return that composite variable to
         *  the calling method.
         */
        indexOf2DArray peakLocation  =  new indexOf2DArray(row, column);
        return peakLocation;
    }  // end of the method "peakFinder2D"
}  // end of Class