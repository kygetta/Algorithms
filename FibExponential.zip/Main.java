
/* COSC 445
 * Casey Cruz & Kylie Hall
 * 
*/
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		System.out.print("Enter a natural number: ");
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();

		System.out
				.println("The Fibonacci value " + n + " is " + FibonacciExponential(n) + " in time complexity Ω(ɸ^n)");
		System.out.println("The Fibonacci value " + n + " is " + FibonacciLinear(n) + " in time complexity Ω(n)");
	}

	/*
	 * Method Description: Method computes and returns the nth term in the Fibonacci
	 * sequence. The time complexity of this method should be Ω(ɸn), where ɸ is the
	 * golden ratio.
	 */
	static int FibonacciExponential(int n) {
		if (n == 0) { // special case
			return 0;
		}
		if (n == 1 || n == 2) { // special case
			return 1;
		}
		return FibonacciExponential(n - 1) + FibonacciExponential(n - 2); // Recursive call
	}

	/*
	 * Method Description: Method computes and returns the nth term in the Fibonacci
	 * sequence. The time complexity of this method should be O(n).
	 */
	static int FibonacciLinear(int n) {
		if (n < 2) { // special case
			return n;
		}
		int j = 0, k = 0, r = 1;
		for (int i = 2; i <= n; ++i) { // stores 2 previous numbers to calculate next value in series in one for loop
										// (O(n))
			j = k;
			k = r;
			r = j + k;
		}
		return r;
	}
}
