import java.util.Random;

public class mergesort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Random rn = new Random();
		int[] num = new int[10]; //length of 10
		
		for(int i=0; i<num.length; i++) {
			num[i] = rn.nextInt(10); //random numbers from 0-25
		}
		System.out.println("Array Before: ");
		for(int element: num) {
			System.out.print(element);
		}
		mergeSort(num);
		
		System.out.println("\n" + "Array After: ");
		for(int element: num) {
			System.out.print(element);
		}
		}
	
	private static void mergeSort(int[] inputArray) {
		int inputLength = inputArray.length;
		
		if(inputLength < 2) {//there's nothing to do it's already sorted
			return;
		}
		
		int midIndex = inputLength / 2;
		int[] leftHalf = new int[midIndex];
		int[] rightHalf = new int[inputLength - midIndex]; //we do inputLength - midIndex for odd numbers in length (i.e. it wouldn't just be int[midIndex]
		
		//now populate leftHalf and rightHalf arrays
		for(int i=0; i<midIndex; i++) {
			leftHalf[i] = inputArray[i];
			//filling in leftHalf of array
		}
		
		for(int i=midIndex; i<inputLength; i++) {
			rightHalf[i-midIndex] = inputArray[i];
			//filling in rightHalf of array
		}
		
		//Now we mergesort each part and in the end we will merge them together
		mergeSort(leftHalf);
		mergeSort(rightHalf);
		
		merge(inputArray, leftHalf, rightHalf);
		//Now merge -- create new method
	}
	
	private static void merge(int[] inputArray, int[] leftHalf, int[] rightHalf) {
		int leftSize = leftHalf.length;
		int rightSize = rightHalf.length;
		
		//We need 3 iterator variables to go through left, right, and merged arrays
		int l=0;
		int r=0;
		int m=0;
		
		
		//comparing elements in left and right arrays
		while(l < leftSize && r < rightSize) {
			if (leftHalf[l] <= rightHalf[r]) {
				inputArray[m] = leftHalf[l];
				l++;
			}
			else {
				inputArray[m] = rightHalf[r];
				r++;
			}
			m++;
		}
		
			while (l<leftSize) {
				inputArray[m] = leftHalf[l];
				l++;
				m++;
			}
			while (r < rightSize) {
				inputArray[m] = rightHalf[r];
				r++;
				m++;
			}
		}
	
		
	}

